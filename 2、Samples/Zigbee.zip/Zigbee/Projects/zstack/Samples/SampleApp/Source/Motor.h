typedef unsigned char uchar;
typedef unsigned int  uint;
void Delay_MSs(uint x);
void MotorData(uchar data);
void MotorCW(uchar Speed);
void MotorCCW(uchar Speed);
void MotorStop(void);
void InitMoIO(void);

void Motor(void);