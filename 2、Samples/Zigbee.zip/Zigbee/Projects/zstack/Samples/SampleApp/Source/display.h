#include "hal_lcd.h"

void Display_Warning();
void Display_Face();
void Display_Finger();
void Display_Welcome();
void Display_Message();
void Display_Default();
void Display_Face1();
void Display_Lock();
void Display_Code();