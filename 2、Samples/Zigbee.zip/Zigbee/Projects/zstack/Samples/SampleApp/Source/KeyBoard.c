#include <ioCC2530.h>
#include <KeyBoard.h>
void delay(){
  for(int i=0;i<1000;i++){
    for(int j=0;j<100;j++);
  }
}
void delays(int n){
  for(int i=0;i<100;i++){
    for(int j=0;j<n;j++);
  }
}
char passwd[6]={'4','2','6','1','1','0'};
char input[6];
int i=0;
int t=0;
int Scan(){
  P0DIR|=0x90;
  P0SEL &= ~0x4d;
  P0IEN |=0x4d;
  EA = 1;
  IEN1 |= 0x20;
  P0IFG &= ~0x4d;
  P1DIR |= 0x3c;
  P0_7=0;
  P0_4=0;
  while(t==0){
    P1=0x04; //P1_2
    P1=0x08; //P1_3
    P1=0x10; //P1_4
    P1=0x20; //P1_5
    if(input[0]=='4' && input[1]=='2' && input[2]=='6' && input[3]=='1' && input[4]=='1' && input[5]=='0'){
      P0_7=1;
      delays(10);
      P0_7=0;
      delays(10);
      P0_7=1;
      delays(10);
      P0_7=0;
      for(int x=0;x<6;x++){
        input[x]=0;
      }
      i=0;
      t=1;
      P0_4=1;
      return 1;
    }
    if(i==6){
      P0_7=1;
      delays(10);
      P0_7=0;
      i=0;
      t=1;
      P0_4=1;
      return 0;
    }
  }
  return -1;
}

#pragma vector = P0INT_VECTOR
__interrupt void P0ISR(void){
  if(P0IFG==0x01){
    delays(5);
    if(P0IFG==0x01){
      if(P1_2==1 && i<6){
        P0_4=1;
        delay();
        P0_4=0;
        input[i]='1';
        i++;
      }
       if(P1_3==1 && i<6){
        P0_4=1;
        delay();
        P0_4=0;
        input[i]='4';
        i++;
      }
       if(P1_4==1 && i<6){
        P0_4=1;
        delay();
        P0_4=0;
        input[i]='7';
        i++;
      }
       if(P1_5==1 && i<6){
        P0_4=1;
        delay();
        P0_4=0;
        input[i]='*';
        i++;
      }
    }
    P0IFG==0x00;
  }
  if(P0IFG==0x04){
    delays(5);
    if(P0IFG==0x04){
     if(P1_2==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='2';
      i++;
    }
     if(P1_3==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='5';
      i++;
    }
     if(P1_4==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='8';
      i++;
    }
     if(P1_5==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='0';
      i++;
    }
    }
    P0IFG==0x00;
  }
  if(P0IFG==0x08){
    delays(5);
    if(P0IFG==0x08){
     if(P1_2==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='3';
      i++;
    }
     if(P1_3==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='6';
      i++;
    }
     if(P1_4==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='9';
      i++;
    }
     if(P1_5==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='#';
      i++;
    }
    }
    P0IFG==0x00;
  }
  if(P0IFG==0x40){
    delays(5);
    if(P0IFG==0x40){
     if(P1_2==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='A';
      i++;
    }
     if(P1_3==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='B';
      i++;
    }
     if(P1_4==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='C';
      i++;
    }
     if(P1_5==1 && i<6){
      P0_4=1;
      delay();
      P0_4=0;
      input[i]='D';
      i++;
    }
    }
    P0IFG==0x00;
  }
  P0IFG=0;
}