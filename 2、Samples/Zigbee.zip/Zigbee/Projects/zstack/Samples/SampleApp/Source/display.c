#include "display.h"

void Display_Warning(){
  LCD_P16x16Ch(3*16,2,4*16);
  LCD_P16x16Ch(4*16,2,5*16);
  LCD_P16x16Ch(3*16,4,6*16);
  LCD_P16x16Ch(4*16,4,7*16);
}

void Display_Face(){
  LCD_P16x16Ch(2*16+8,3,8*16);
  LCD_P16x16Ch(3*16+8,3,9*16);
  LCD_P16x16Ch(4*16+8,3,10*16);
}

void Display_Finger(){
  LCD_P16x16Ch(2*16,3,11*16);
  LCD_P16x16Ch(3*16,3,12*16);
  LCD_P16x16Ch(4*16,3,13*16);
  LCD_P16x16Ch(5*16,3,14*16);
}

void Display_Welcome(){
  LCD_P16x16Ch(2*16+8,3,0*16);
  LCD_P16x16Ch(3*16+8,3,1*16);
}

void Display_Message(){
  LCD_P16x16Ch(0*16,0,15*16);
  LCD_P16x16Ch1(1*16,0,0*16);
  LCD_P16x16Ch(2*16,0,2*16);
  HalLcdWriteString("13526561374",HAL_LCD_LINE_2);
  HalLcdWriteString("QQ:",HAL_LCD_LINE_3);
  HalLcdWriteString("1353182489",HAL_LCD_LINE_4);
}

void Display_Default(){
  LCD_P16x16Ch1(0*16+1,0,13*16);
  LCD_P16x16Ch1(1*16+1,0,14*16);
  LCD_P16x16Ch1(2*16+1,0,1*16);
  LCD_P16x16Ch1(3*16+1,0,2*16);
  LCD_P16x16Ch1(4*16+1,0,3*16);
  LCD_P16x16Ch1(5*16+1,0,4*16);
  LCD_P16x16Ch1(6*16+1,0,5*16);
  LCD_P16x16Ch1(7*16+1,0,6*16);
  
  LCD_P16x16Ch(0*16+1,3,3*16);
  LCD_P16x16Ch1(1*16+1,3,15*16);
  LCD_P16x16Ch1(2*16+1,3,1*16);
  LCD_P16x16Ch1(3*16+1,3,2*16);
  LCD_P16x16Ch1(4*16+1,3,3*16);
  LCD_P16x16Ch1(5*16+1,3,4*16);
  LCD_P16x16Ch1(6*16+1,3,5*16);
  LCD_P16x16Ch1(7*16+1,3,6*16);
  
  LCD_P16x16Ch1(1*16+1,6,7*16);
  LCD_P16x16Ch1(2*16+1,6,8*16);
  LCD_P16x16Ch1(3*16+1,6,9*16);
  LCD_P16x16Ch1(4*16+1,6,10*16);
  LCD_P16x16Ch1(5*16+1,6,11*16);
  LCD_P16x16Ch1(6*16+1,6,12*16);
}
void Display_Face1(){
  LCD_P16x16Ch2(2*16,2,0*16);
  LCD_P16x16Ch2(4*16,2,1*16);
  LCD_P16x16Ch2(3*16,4,2*16);
}
void Display_Lock(){
  LCD_P16x16Ch2(3*16+8,3,3*16);

}
void Display_Code(){
  LCD_P16x16Ch2(4*16,2,4*16);
  LCD_P16x16Ch2(5*16,2,5*16);
  LCD_P16x16Ch2(4*16,4,6*16);
  LCD_P16x16Ch2(5*16,4,7*16);
  LCD_P16x16Ch2(1*16,0,8*16); //ɨ
  LCD_P16x16Ch2(1*16,2,9*16); //��
  LCD_P16x16Ch2(1*16,4,10*16); //��
  LCD_P16x16Ch2(1*16,6,11*16); //��
}