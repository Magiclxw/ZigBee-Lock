  package cn.itcast.mqttclient;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;

  public class MainActivity extends AppCompatActivity{
    private Button keyopen,history,send,lock,unlock,apply;
    static TextView lockstate,lockorunlock,alarm,th,ht;
    private EditText editText;
    String content,sendmessage;
    static String mqttweb="tcp://baidu.com:1833";
    static String httpweb="www.baidu.com:8080";
    int t=0;
    MqttClient client = null;
    InputStream inputStream;
    public static Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        keyopen = (Button) findViewById(R.id.open);
        history = (Button) findViewById(R.id.history);
        lockstate = (TextView) findViewById(R.id.lockstate);
        lockorunlock = (TextView) findViewById(R.id.lockorunlock);
        send = (Button) findViewById(R.id.send);
        lock = (Button) findViewById(R.id.lock);
        unlock = (Button) findViewById(R.id.unlock);
        editText = (EditText) findViewById(R.id.edit);
        alarm = (TextView) findViewById(R.id.alarm);
        mContext=getApplicationContext();
        apply=(Button)findViewById(R.id.apply);
        th=(TextView)findViewById(R.id.t);
        ht=(TextView)findViewById(R.id.h);
        new Thread(new UpdateState()).start();
        String subTopic = "LockState";
        String subTopic1="TH";
        String subTopic2="LockorUnlock";
        String pubTopic = "LockControl";
        String opencontent = "open";
        String closecontent = "close";
        String lockcontent = "lock";
        String unlockcontent = "unlock";
        int qos = 0;
        String broker = mqttweb;
        String clientId = "Controller";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            client = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            // 设置回调
            client.setCallback(new OnMessageCallback());
            // 建立连接
            System.out.println("Connecting to broker: " + broker);
            try {
                client.connect(connOpts);
            } catch (MqttException e) {
                e.printStackTrace();
            }
            try {
                client.subscribe(subTopic);
                String receivedMsg = OnMessageCallback.res;
                if(receivedMsg.equals("open")){
                    lockstate.setText("当前状态：打开");
                }
                if(receivedMsg.equals("close")){
                    lockstate.setText("当前状态：关闭");
                }

            } catch (MqttException e) {
                e.printStackTrace();
            }
            try {
                client.subscribe(subTopic);
                String receivedMsg = OnMessageCallback.res;
                if(receivedMsg.equals("open")){
                    lockstate.setText("当前状态：打开");
                }
                if(receivedMsg.equals("close")){
                    lockstate.setText("当前状态：关闭");
                }

            } catch (MqttException e) {
                e.printStackTrace();
            }
            try {
                client.subscribe(subTopic1);
                String receivedMsg = OnMessageCallback.res;
                if(receivedMsg.equals("lock")){
                    lockorunlock.setText(receivedMsg);
                }
                if(receivedMsg.equals("unlock")){
                    lockorunlock.setText(receivedMsg);
                }
            } catch (MqttException e) {
                e.printStackTrace();
            }
            try {
                client.subscribe(subTopic2);
                String receivedMsg = OnMessageCallback.res;
                if(receivedMsg.startsWith("TH")){
                    String t=receivedMsg.substring(2,4);
                    String h=receivedMsg.substring(5,7);
                    th.setText(t);
                    ht.setText(h);
                }
            } catch (MqttException e) {
                e.printStackTrace();
            }


        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
        keyopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String receivedMsg = OnMessageCallback.res;
                System.out.println(receivedMsg);
                MqttMessage message = new MqttMessage(opencontent.getBytes());
                message.setQos(qos);
                try {
                    client.publish(pubTopic, message);
                    System.out.println("Message published");
                } catch (MqttException e) {
                    e.printStackTrace();
                }

            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, History.class);
                startActivity(intent);
            }
        });
        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, ApplyJson.class);
                startActivity(intent);
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendmessage = editText.getText().toString();
                if (TextUtils.isEmpty(sendmessage)) {
                    Toast.makeText(MainActivity.this, "您还未输入内容", Toast.LENGTH_LONG).show();
                } else if (sendmessage.length() > 62) {
                    Toast.makeText(MainActivity.this, "字数过长，当前" + sendmessage.length() + "个", Toast.LENGTH_LONG).show();
                } else {
                    sendmessage = "rc" + sendmessage+"..";
                    MqttMessage message = new MqttMessage(sendmessage.getBytes());
                    message.setQos(qos);
                    try {
                        client.publish(pubTopic, message);
                        Toast.makeText(MainActivity.this, "发送成功", Toast.LENGTH_LONG).show();
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String receivedMsg = OnMessageCallback.res;
                System.out.println(receivedMsg);
                    MqttMessage message = new MqttMessage(lockcontent.getBytes());
                    message.setQos(qos);
                    try {
                        client.publish(pubTopic, message);
                        System.out.println("Message published");
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
            }
        });
        unlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String receivedMsg = OnMessageCallback.res;
                System.out.println(receivedMsg);
                    MqttMessage message = new MqttMessage(unlockcontent.getBytes());
                    message.setQos(qos);
                    try {
                        client.publish(pubTopic, message);
                        System.out.println("Message published");
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
            }
        });
    }
    public static Handler handler=new Handler(){
        @SuppressLint("HandlerLeak")
        public void handleMessage(Message message){
            Bundle bundle=message.getData();

            String s=bundle.getString("lockstate");
            if(s.equals("open")){
                lockstate.setText("当前状态：打开");
            }
            if (s.equals("close")){
                lockstate.setText("当前状态：关闭");
            }
            if (s.equals("lock")){
                lockorunlock.setText("反锁");
            }
            if (s.equals("unlock")){
                lockorunlock.setText("解锁");
            }
            if(s.startsWith("TH")){
                String t=s.substring(2,4);
                String h=s.substring(5,7);
                th.setText(t);
                ht.setText(h);
            }
            if (s.equals("alarm")){
                Date date=new Date();
                DateFormat format=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.MEDIUM);
                alarm.setText("收到呼叫:"+format.format(date));
                Toast.makeText(mContext, "收到呼叫:"+format.format(date), Toast.LENGTH_LONG).show();
            }
            System.out.println("主程序收到"+s);
        }
    };
    public static void alarm(){
        AlertDialog dialog;
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.mContext)
                .setTitle("通知")
                .setIcon(R.mipmap.cycle)
                .setMessage("收到呼叫")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog=builder.create();
        dialog.show();
    }
    public void onBackPressed(){
        if(t==1){
            MainActivity.this.finish();
        }
        if(t==0) {
            Toast.makeText(MainActivity.this, "再次返回退出", Toast.LENGTH_LONG).show();
            t++;
        }
    }

}
