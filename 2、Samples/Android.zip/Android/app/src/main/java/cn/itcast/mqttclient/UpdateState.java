package cn.itcast.mqttclient;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Looper;
import android.os.Message;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import static cn.itcast.mqttclient.MainActivity.mContext;


public class UpdateState implements Runnable{
    static String lockstate="null";
    static String temp="";
    @Override
    public void run() {
        while(!Thread.currentThread().isInterrupted()){
            Message message=new Message();
            Bundle bundle=new Bundle();
            bundle.putString("lockstate",lockstate);
            if(lockstate!=temp) {
                message.setData(bundle);
                temp = lockstate;
                MainActivity.handler.sendMessage(message);
                System.out.println("线程收到" + lockstate);
            }
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
    }
}
