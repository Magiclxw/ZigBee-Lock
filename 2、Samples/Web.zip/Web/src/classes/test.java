package classes;

import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import SQL.DBUtilsDao;

public class test {
		// TODO Auto-generated method stub
		private static DBUtilsDao dao=new DBUtilsDao();
		
		public static void testInsert(String result,String way) throws SQLException{				//插入数据库当前时间
			Time time=new Time();
			Date date=new Date();
			DateFormat mediumFormat=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.MEDIUM);  //获取时间
			String times=mediumFormat.format(date);
			time.setTimes(times);
			time.setResult(result);
			time.setWay(way);
			boolean b=dao.insert(time);
			System.out.println(b);
		}
		public static void addRequest(String username,String reason) throws SQLException{				//插入数据库当前时间
			Req req=new Req();
			Date date=new Date();
			DateFormat mediumFormat=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.MEDIUM);  //获取时间
			String times=mediumFormat.format(date);
			req.setReason(reason);;
			req.setUsername(username);
			req.setTimes(times);
			boolean b=dao.insertreq(req);
			System.out.println(b);
		}
		public static List findall() throws SQLException{					//查询数据库中所有数据
			List s=(List) dao.findAll();
//			int a=s.size();										//获取数据长度
			return s;
		}
		public static List Reqfindall() throws SQLException{					//查询数据库中所有数据
			List s=(List) dao.ReqfindAll();
//			int a=s.size();										//获取数据长度
			return s;
		}
		public static void find() throws SQLException{						//查询数据库中指定数据
			try {
				for(int i=1;;i++) {
					Time time=dao.find(i);
					System.out.println(time.getTimes());
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		public static void updatetrue() throws SQLException{		//设置为true
			Switch sw=new Switch();
			sw.setId(1);
			sw.setKg("true");
			boolean b=dao.updateSW(sw);
			System.out.println(b);
		}
		public static void updatefalse() throws SQLException{		//设置为false
			Switch sw=new Switch();
			sw.setId(1);
			sw.setKg("false");
			boolean b=dao.updateSW(sw);
			System.out.println(b);
		}
		public static void update(String s) throws SQLException{		//设置为false
			Switch sw=new Switch();
			sw.setId(1);
			sw.setKg(s);
			boolean b=dao.updateSW(sw);
			System.out.println(b);
		}
		public static String findKG() throws SQLException{              //获取开关状态
			try {
				Switch sw=dao.findSW(1);
				System.out.println(sw.getKg());
				return sw.getKg();
			} catch (Exception e) {
				// TODO: handle exception
			}
			return null;
		}
		public static void main(String[] args)throws SQLException {
			//testInsert();
			//findall();
			//findKG();
			find();
			//updatetrue();
			//updatefalse();
		}
}
