package web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import classes.test;


/**
 * Servlet implementation class UpdateSQL
 */
public class UpdateSQL extends HttpServlet {
	private static final int BUFFER_SIZE = 1024 * 8;
	private String Lock;
	private static final long serialVersionUID = 1L;
	//接收android端发来的数据，如果kg=true，更新数据库为true；kg=fales，更新数据库为false
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		String rec=request.getParameter("kg");
		if(("true").equals(rec)) {
			try {
				test.updatetrue();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}else{
			try {
				test.updatefalse();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		InputStream in=request.getInputStream();
		BufferedReader reader=new BufferedReader(new InputStreamReader(in));
		String body=read(reader);
		net.sf.json.JSONObject J=net.sf.json.JSONObject.fromObject(body);
		Lock=J.getString("Lock");
		try {
			test.update(Lock);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String read(Reader reader) throws IOException
    {
        StringWriter writer = new StringWriter();
        try
        {
            write(reader, writer);
            return writer.getBuffer().toString();
        }
        finally{ writer.close(); }
    }
	
	public static long write(Reader reader, Writer writer) throws IOException
    {
        return write(reader, writer, BUFFER_SIZE);
    }
	//把缓存器的json数据写入缓存区
	public static long write(Reader reader, Writer writer, int bufferSize) throws IOException
    {
        int read;
        long total = 0;
        char[] buf = new char[BUFFER_SIZE];
        while( ( read = reader.read(buf) ) != -1 )
        {
            writer.write(buf, 0, read);
            total += read;
        }
        return total;
    }
}
