package web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.test;

/**
 * Servlet implementation class AddTime
 */
public class AddTime extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		String result=request.getParameter("result");	//成功or失败
		String way=request.getParameter("way");
		if(("success").equals(result)) {
			if(("finger").equals(way)) {
				try {
					test.testInsert("成功","指纹");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(("cloud").equals(way)){
				try {
					test.testInsert("成功","云");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(("web").equals(way)){
				try {
					test.testInsert("成功","网页");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		if(("failure").equals(result)){
			if(("finger").equals(way)) {
				try {
					test.testInsert("失败","指纹");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(("cloud").equals(way)){
				try {
					test.testInsert("失败","云");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(("web").equals(way)){
				try {
					test.testInsert("失败","网页");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
