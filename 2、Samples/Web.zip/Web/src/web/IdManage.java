package web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import classes.OnMessageCallback;

/**
 * Servlet implementation class IdManage
 */
public class IdManage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String broker = "tcp://magichello.xyz:1883";
    String clientId = "WebController";
    MqttClient client = null;
    String pubTopic = "LockControl";
    int qos = 0;
    MemoryPersistence persistence = new MemoryPersistence();
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		try {
            client = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            // 设置回调
            client.setCallback(new OnMessageCallback());
            // 建立连接
            System.out.println("Connecting to broker: " + broker);
            try {
                client.connect(connOpts);
            } catch (MqttException e) {
                e.printStackTrace();
            }


        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
		if(("Magic").equals(username) && ("Aa123456").equals(password)) {
			String lockcontent="websuccess";
			MqttMessage message = new MqttMessage(lockcontent.getBytes());
            message.setQos(qos);
            try {
                client.publish(pubTopic, message);
                System.out.println("Message published");
            } catch (MqttException e) {
                e.printStackTrace();
            }
			response.sendRedirect("logok.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
