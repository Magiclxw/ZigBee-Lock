package SQL;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import classes.Req;
import classes.Switch;
import classes.Time;

public class DBUtilsDao {												//查询所有
	public List findAll() throws SQLException{
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="select * from locks order by id desc limit 100;";
		List list=(List)runner.query(sql, new BeanListHandler(Time.class));
		return list;
	}
	public List ReqfindAll() throws SQLException{
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="select * from request order by id desc limit 100;";
		List list=(List)runner.query(sql, new BeanListHandler(Req.class));
		return list;
	}
	public Boolean insert(Time time) throws SQLException{                //插入
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="insert into locks(times,result,way) values (?,?,?)";
		int num=runner.update(sql,new Object[] {time.getTimes(),time.getResult(),time.getWay()});
		if(num>0) {
			return true;
		}
		return false;
	}
	public Boolean insertreq(Req req) throws SQLException{                //插入
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="insert into request(times,username,reason) values (?,?,?)";
		int num=runner.update(sql,new Object[] {req.getTimes(),req.getUsername(),req.getReason()});
		if(num>0) {
			return true;
		}
		return false;
	}
	public Time find(int id) throws SQLException{
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="select * from locks where id=?";
		Time time=(Time)runner.query(sql, new BeanHandler(Time.class),new Object[] {id});
		return time;
	}
	public Boolean insertSW(Switch sw) throws SQLException{                //插入
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="insert into switch(id,kg) values (?,?)";
		int num=runner.update(sql,new Object[] {sw.getId(),sw.getKg()});
		if(num>0) {
			return true;
		}
		return false;
	}
	public Switch findSW(int id) throws SQLException{                       //查找
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="select * from switch where id=?";
		Switch sw=(Switch)runner.query(sql, new BeanHandler(Switch.class),new Object[] {id});
		return sw;
	}
	public Boolean updateSW(Switch sw) throws SQLException{
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="update switch set kg=? where id=?";
		int num=runner.update(sql,new Object[] {sw.getKg(),sw.getId()});
		if(num>0) {
			return true;
		}
		return false;
	}
	public Boolean deleteSW (int id) throws SQLException{
		QueryRunner runner=new QueryRunner(c3p0.getDataSource());
		String sql="delete from switch where id=?";
		int num=runner.update(sql,id);
		if(num>0) {
			return true;
		}
		return false;
	}
}
