package SQL;

import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class c3p0 {
	private static DataSource ds;
	static {
		ds=new ComboPooledDataSource("test");
	}
	public static DataSource getDataSource() {
		return ds;
	}
}
